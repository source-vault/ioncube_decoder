================================================================================
                    SourceVault CLI Decoder v1.0.0
       Cross-Platform High-Performance ionCube / Zend / SG Decoder
                          (Command: decoder)
================================================================================

SourceVault Decoder is a standalone, lightweight, zero-dependency command-line
tool designed to decode protected PHP scripts and full directories through the
official SourceVault service.

HOW IT WORKS:
-------------
When you submit a file or directory for decoding, the decoder client automatically:
  1. Submits the target script to the SourceVault cloud processing engine.
  2. Waits for the specialized decoding worker to process the protected file.
  3. Displays a real-time progress indicator in your terminal.
  4. Automatically downloads and reconstructs the decoded PHP source code directly
     to your designated output destination.

Everything happens seamlessly in a single command.


QUICK START:
------------
1. Test connection with your API Key:
   decoder -key svk_xxxx ping

2. Check your balance:
   decoder credits

3. Decode a single PHP script:
   decoder -i encoded.php -o decoded.php -type ioncube -php 8

4. Decode an entire folder of encoded files:
   decoder -i ./protected_app -o ./clean_app -type sourceguardian -php 7 -concurrency 6

5. Save your API key permanently:
   decoder config -key svk_xxxxxxxxxxxx


COMMANDS:
---------
  decode <path>       Decode a file or directory
  credits, balance    Display remaining account credits
  ping                Verify API key and test server latency
  config              View or update saved settings
  version             Show client version
  help                Display help message


SUPPORTED DECODERS & PHP VERSIONS:
----------------------------------
  - Decoders:     ioncube, zend, sourceguardian (default: ioncube)
  - PHP Versions: 8, 7, 5 (default: 8)


CONFIGURATION:
--------------
Settings are saved in your user home directory:
  ~/.sourcevault/config.json

Environment variables:
  SOURCEVAULT_API_KEY     Your API key
  DECODER_API_KEY         Alternative API key env variable

================================================================================
